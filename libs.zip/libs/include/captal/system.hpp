#ifndef CAPTAL_SYSTEM_HPP_INCLUDED
#define CAPTAL_SYSTEM_HPP_INCLUDED

#include "config.hpp"

#include <functional>

#include <entt/entity/registry.hpp>

namespace cpt
{

using system_callback_t = std::function<void(float delta_time)>;

class system
{
public:

    void update(float delta_time);

private:
    system_callback_t m_callback{};
};

}

#endif
