#ifndef CAPTAL_COMPONENTS_LISTENER_HPP_INCLUDED
#define CAPTAL_COMPONENTS_LISTENER_HPP_INCLUDED

#include "../config.hpp"

namespace cpt
{

namespace components
{

struct listener
{

};

}

}

#endif
