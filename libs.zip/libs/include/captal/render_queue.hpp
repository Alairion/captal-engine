#ifndef CAPTAL_RENDER_QUEUE_HPP_INCLUDED
#define CAPTAL_RENDER_QUEUE_HPP_INCLUDED

#include "config.hpp"

namespace cpt
{

class render_queue
{
public:

private:

};

}

#endif
