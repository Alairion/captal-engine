#ifndef CAPTAL_DRAWABLE_HPP_INCLUDED
#define CAPTAL_DRAWABLE_HPP_INCLUDED

#include "config.hpp"

#include <vector>

#include "view.hpp"

#include <glm/mat4x4.hpp>

namespace cpt
{

class renderable;

namespace components
{

class drawable
{
public:
    drawable() = default;
    drawable(renderable& attachment);
    ~drawable() = default;
    drawable(const drawable&) = delete;
    drawable& operator=(const drawable&) = delete;
    drawable(drawable&&) noexcept = default;
    drawable& operator=(drawable&&) noexcept = default;

    void attach(renderable& attachment) noexcept;

    void hide() noexcept
    {
        m_hidden = true;
    }

    void show() noexcept
    {
        m_hidden = false;
    }

    renderable* attachment() const noexcept
    {
        return m_attachment;
    }

    bool hidden() const noexcept
    {
        return m_hidden;
    }

private:
    renderable* m_attachment{};
    bool m_hidden{};
};

}

}

#endif
