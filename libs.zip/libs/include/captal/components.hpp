#ifndef CAPTAL_COMPONENTS_HPP_INCLUDED
#define CAPTAL_COMPONENTS_HPP_INCLUDED

#include "config.hpp"

#include <glm/vec3.hpp>

namespace cpt
{

namespace components
{

struct position : glm::vec3
{
    using glm::vec3::vec;
    using glm::vec3::operator=;
};

struct origin : glm::vec3
{
    using glm::vec3::vec;
    using glm::vec3::operator=;
};

struct velocity : glm::vec3
{
    using glm::vec3::vec;
    using glm::vec3::operator=;
};

}

}

#endif
