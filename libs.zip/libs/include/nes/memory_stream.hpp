///////////////////////////////////////////////////////////
/// Copyright 2019 Alexy Pellegrini
///
/// Permission is hereby granted, free of charge,
/// to any person obtaining a copy of this software
/// and associated documentation files (the "Software"),
/// to deal in the Software without restriction,
/// including without limitation the rights to use,
/// copy, modify, merge, publish, distribute, sublicense,
/// and/or sell copies of the Software, and to permit
/// persons to whom the Software is furnished to do so,
/// subject to the following conditions:
///
/// The above copyright notice and this permission notice
/// shall be included in all copies or substantial portions
/// of the Software.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
/// ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
/// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
/// PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
/// SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
/// ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
/// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
/// OR OTHER DEALINGS IN THE SOFTWARE.
///////////////////////////////////////////////////////////

#ifndef NOT_ENOUGH_STANDARDS_MEMORY_STREAM
#define NOT_ENOUGH_STANDARDS_MEMORY_STREAM

#include <streambuf>
#include <istream>
#include <ostream>

template<class CharT, class Traits = std::char_traits<CharT>, class Allocator = std::allocator<CharT>>
class basic_memory_streambuf : public std::basic_streambuf<CharT, Traits>
{
private:
    using parent_type = std::basic_streambuf<CharT, Traits>;

public:
    using char_type = CharT;
    using traits_type = Traits;
    using allocator_type = Allocator;
    using int_type = typename traits_type::int_type;
    using pos_type = typename traits_type::pos_type;
    using off_type = typename traits_type::off_type;

public:
    using string_type = std::basic_string<char_type, traits_type, allocator_type>;

public:
    using value_type = typename string_type::value_type;
    using size_type = typename string_type::size_type;
    using difference_type = typename string_type::difference_type;
    using reference = typename string_type::reference;
    using const_reference = typename string_type::const_reference;
    using pointer = typename string_type::pointer;
    using const_pointer = typename string_type::const_pointer;
    using iterator = typename string_type::iterator;
    using const_iterator = typename string_type::const_iterator;
    using reverse_iterator = typename string_type::reverse_iterator;
    using const_reverse_iterator = typename string_type::const_reverse_iterator;

public:
    basic_memory_streambuf() = default;

    explicit basic_memory_streambuf(const std::string& str, std::ios_base::openmode mode)
    {

    }

    virtual ~basic_memory_streambuf();

    basic_memory_streambuf(const basic_memory_streambuf&) = delete;
    basic_memory_streambuf& operator=(const basic_memory_streambuf&) = delete;

    basic_memory_streambuf(basic_memory_streambuf&& other) noexcept
    :parent_type{std::move(other)}
    ,m_str{std::move(other.m_str)}
    {

    }

    basic_memory_streambuf& operator=(basic_memory_streambuf&& other) noexcept
    {
        parent_type::operator=(std::move(other));
        m_str = std::move(other.m_str);

        return *this;
    }

private:
    string_type m_str{};
    std::ios_base::openmode m_mode{};
};

#endif
